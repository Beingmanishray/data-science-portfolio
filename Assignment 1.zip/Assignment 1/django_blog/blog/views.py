from django.shortcuts import render
from .models import Post
# Create your views here.
def blog_list(request):
    post = Post.object.all()
    context = {
        'blog_list':Post
    }
    return render(request, "templates/blog/blog_list.html",context)